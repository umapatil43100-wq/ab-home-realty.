
export default function Home() {
  return (
    <div style={{padding:40, fontSize:28}}>
      <h1>AB Home Realty Website</h1>
      <p>Demo site setup complete. Full version will load soon.</p>
    </div>
  );
}
